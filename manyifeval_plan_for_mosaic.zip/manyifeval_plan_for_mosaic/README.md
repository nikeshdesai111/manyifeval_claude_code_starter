# ManyIFEval probing plan: handoff for a MOSAIC adaptation

These are the design documents of a study that predicts per-rule instruction violations of
LLMs (Llama-3.1-8B-Instruct, Qwen3-8B) from pre-generation internal features, using ManyIFEval.
No data, code or results beyond the frozen analysis plan are included.

## Read in this order
1. `research_plan.md`: short summary of the plan (v3.6).
2. `docs/decision_tracker.md`: every decision and amendment, with current counts. Where it
   disagrees with the docx, the tracker wins (216 tasks / 72 groups / 57 train + 15 test groups).
3. `docs/research_plan_original_v3.4.docx`: full method (design, probes, evaluation, hypotheses).
4. `results/prespec/analysis_plan.md`: frozen analysis plan (metrics, contrasts, controlled analyses).

## Reference
- `docs/probing_schema.md`, `docs/storage_schema.md`: feature definitions and storage layout.
- `docs/audit_findings.md`: ManyIFEval-specific problems found during the build (a checklist of what to audit in MOSAIC).
- `configs/experiment.yaml`: decoding settings, seeds, token cap, probing grid.
- `docs/pilot_report.md`, `docs/pilot_report_betty.md`: measured throughput and cost (Apple M4 Max; B200 GPU cluster).
- `docs/task_family_rubric.md`, `configs/task_families_v1.csv`: proposed task-family grouping (ManyIFEval tasks).
- `CLAUDE.md`, `PROMPT_probing_and_results.md`: instructions used to drive the build with Claude Code; reusable as templates.

## What must change for MOSAIC
1. Rule taxonomy and verifiers: ManyIFEval uses 15 deterministic code checkers (two of them
   also call langdetect). If MOSAIC uses an LLM judge, labels become noisier.
2. Rule pool and compatibility: "6 rules, 6 distinct types, jointly satisfiable" relies on
   ManyIFEval's conflict lists and parameter generators.
3. Counts: tasks, groups, k range and the train/test split all derive from ManyIFEval's 216 tasks.

The design itself (nested cyclic chains, balanced orderings, grouped split, type-specific
probe heads, grouped CV, frozen pre-specification) is benchmark-agnostic.
